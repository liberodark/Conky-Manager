# Informant-Conky
Conky with every information You need about your machine
## Preview
![alt text](https://raw.githubusercontent.com/addy-dclxvi/informant-conky/master/preview.jpg)
## Getting Started
Make sure You have Roboto font installed. If You don't have or unsure, install it
 ```
sudo pacman -S ttf-roboto
```
## Installation
Change directory to your conky folder
```
cd ~/.config/conky
```
Then clone this conky
```
git clone https://github.com/addy-dclxvi/informant-conky
```
Then load this conky using your conky manager
## Based On
[Manjaro Openbox Conky](https://github.com/holmeslinux/Manjaro-Openbox/blob/master/openbox-overlay/etc/skel/.conkyrc)
## License
Feel free to modify and share this conky
## My Links
[Google+](https://plus.google.com/+AdhiPambudi)
[Deviant Art](http://addy-dclxvi.deviantart.com/)

